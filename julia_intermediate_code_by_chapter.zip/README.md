# Extracted Code — Julia Intermediate Guide

Chapter-by-chapter code collected from the uploaded manuscript.

## Contents
- 00_INTRODUCTION/`00_INTRODUCTION_code.jl` — 41 lines
- 01_Chapter_1/`01_Chapter_1_code.jl` — 70 lines
- 02_Chapter_2/`02_Chapter_2_code.jl` — 77 lines
- 03_Chapter_3/`03_Chapter_3_code.jl` — 94 lines
- 04_Chapter_4/`04_Chapter_4_code.jl` — 97 lines
- 05_Chapter_5/`05_Chapter_5_code.jl` — 111 lines
- 06_Chapter_6/`06_Chapter_6_code.jl` — 120 lines
- 07_Chapter_7/`07_Chapter_7_code.jl` — 115 lines
- 08_Chapter_8/`08_Chapter_8_code.jl` — 89 lines
- 09_Chapter_9/`09_Chapter_9_code.jl` — 108 lines
- 10137_Chapter_10137/`10137_Chapter_10137_code.jl` — 2 lines
- 10_Chapter_10/`10_Chapter_10_code.jl` — 145 lines
- 11151_Chapter_11151/`11151_Chapter_11151_code.jl` — 0 lines (placeholder)
- 11_Chapter_11/`11_Chapter_11_code.jl` — 117 lines
- 12164_Chapter_12164/`12164_Chapter_12164_code.jl` — 2 lines
- 128_Chapter_128/`128_Chapter_128_code.jl` — 1 lines
- 12_Chapter_12/`12_Chapter_12_code.jl` — 79 lines
- 13176_Chapter_13176/`13176_Chapter_13176_code.jl` — 1 lines
- 13_Chapter_13/`13_Chapter_13_code.jl` — 87 lines
- 14190_Chapter_14190/`14190_Chapter_14190_code.jl` — 0 lines (placeholder)
- 14_Chapter_14/`14_Chapter_14_code.jl` — 102 lines
- 239_Chapter_239/`239_Chapter_239_code.jl` — 5 lines
- 350_Chapter_350/`350_Chapter_350_code.jl` — 2 lines
- 462_Chapter_462/`462_Chapter_462_code.jl` — 3 lines
- 575_Chapter_575/`575_Chapter_575_code.jl` — 1 lines
- 686_Chapter_686/`686_Chapter_686_code.jl` — 4 lines
- 798_Chapter_798/`798_Chapter_798_code.jl` — 4 lines
- 8111_Chapter_8111/`8111_Chapter_8111_code.jl` — 3 lines
- 9124_Chapter_9124/`9124_Chapter_9124_code.jl` — 4 lines