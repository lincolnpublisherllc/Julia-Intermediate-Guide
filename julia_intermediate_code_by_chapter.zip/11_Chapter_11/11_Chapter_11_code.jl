In real-world applications, interacting with external systems like databases and APIs is a fundamental task. Whether you're building a web application that needs to store user data, or you need to interact with external services to fetch or send data, database integration and API communication are essential skills.
How to interact with APIs to fetch or send data to external services.
Best practices for managing database transactions and performing SQL queries in Julia.
By the end of this chapter, you will be able to:
SQLite is a lightweight, file-based relational database that is commonly used for smaller applications. The SQLite.jl package provides a simple interface to work with SQLite databases.
Pkg.add("SQLite")
using SQLite

# Connect to a SQLite database (or create it if it doesn't exist)
# Create a table
# Insert data into the table
# Query the table
# Display the result
for row in rows
    println(row)
end
PostgreSQL is a powerful relational database system. Julia has support for PostgreSQL through the LibPQ.jl package.
Pkg.add("LibPQ")
using LibPQ

# Connect to PostgreSQL
# Execute a query
# Print the result
println(result)

# Close the connection
MongoDB is a NoSQL database that stores data in a flexible, document-oriented format. Julia has support for MongoDB through the MongoDB.jl package.
Pkg.add("MongoDB")
using MongoDB

# Connect to MongoDB
client = MongoClient("mongodb://localhost:27017")

# Access a database and collection
# Insert data
collection.insert_one(Dict("name" => "Alice", "age" => 30))

# Query the collection
users = collection.find(Dict("age" => 30))

# Print the result
for user in users
    println(user)
end

APIs (Application Programming Interfaces) allow applications to communicate with external services over the web. In Julia, you can use the HTTP.jl package to send HTTP requests to external APIs and receive responses.
Pkg.add("HTTP")
Pkg.add("JSON")  # For working with JSON responses
Step 2: Send a GET Request to an APIHere, we’ll make a simple request to a public API (for example, the JSONPlaceholder API, which returns fake data for testing and prototyping).
using HTTP
using JSON

# Send a GET request
response = HTTP.get("https://jsonplaceholder.typicode.com/users")

# Parse the JSON response
data = JSON.parse(String(response.body))

# Print the data
println(data)
2.2 Sending Data to an API (POST Request)
You can also use POST requests to send data to an API.
# Send a POST request
response = HTTP.post("https://jsonplaceholder.typicode.com/posts",
    body = JSON.json(Dict("title" => "New Post", "body" => "Content", "userId" => 1)))

# Print the response
println(String(response.body))
We send a POST request with a JSON body to create a new post.
using SQLite

# Open a database connection
# Start a transaction
# Perform multiple database operations
# Commit the transaction
# Close the connection
using LibPQ

# Connect to PostgreSQL
# Start a transaction
# Perform multiple operations
# Commit the transaction
# Close the connection
using SQLite

# Create a new database and table
Step 2: Create Functions for CRUD Operations
# Create a new user
function create_user(db, name, age)
end

# Retrieve all users
function get_users(db)
end

# Update a user's age
function update_user(db, id, new_age)
end

# Delete a user
function delete_user(db, id)
end
Step 3: Test the CRUD Operations
# Test the functions
println(get_users(db))

update_user(db, 1, 31)  # Update Alice's age
println(get_users(db))

delete_user(db, 2)  # Delete Bob
println(get_users(db))

Fetches data from a public API (e.g., JSONPlaceholder).
Use HTTP.jl to send a GET request to the public API.
Parse the JSON response using JSON.jl.
In this chapter, we covered how to integrate databases and external services into your Julia applications. We explored how to connect to SQLite, PostgreSQL, and MongoDB, and how to work with APIs to send and receive data. We also learned about database transactions and how to perform basic SQL queries within Julia.
With these skills, you can now build robust, data-driven applications that integrate seamlessly with external services and databases, laying the foundation for more complex and scalable projects.
