One of the core tasks in data science and scientific computing is working with external data. In Julia, you can efficiently read, write, and manipulate data from various file formats like CSV, JSON, HDF5, and more. Julia’s ecosystem provides powerful tools for interacting with these formats, which are essential for tasks such as data analysis, data cleaning, and preparing data for modeling.
Working with different data formats: CSV, JSON, HDF5, and others.
By the end of this chapter, you'll be comfortable working with external data in Julia, and you'll have learned how to clean and preprocess data for analysis or modeling.

In Julia, file handling is straightforward, and several packages make reading and writing data from files efficient and simple. Let’s explore the basic techniques for handling files in Julia.
The CSV.jl package is commonly used for working with CSV files. It provides easy-to-use functions for reading, writing, and manipulating CSV data.
using Pkg
Pkg.add("CSV")
Pkg.add("DataFrames")  # For handling data in a structured format
Reading CSV Files:Use the CSV.File() function to read a CSV file into a DataFrame (a tabular structure).
using CSV
using DataFrames

df = CSV.File("data.csv") |> DataFrame
println(first(df, 5))  # Display first 5 rows of the dataframe
Writing CSV Files:Use CSV.write() to write a DataFrame or an array to a CSV file:
CSV.write("output.csv", df)
Reading and Writing JSON Files
The JSON.jl package is used for working with JSON data. JSON is a lightweight format for storing and exchanging data, commonly used for APIs and configuration files.
To install the JSON package, use:
Pkg.add("JSON")
Reading JSON Files:
using JSON

# Read JSON file
json_data = JSON.parsefile("data.json")
println(json_data)
Writing JSON Files:
JSON.print("output.json", json_data)
Reading and Writing HDF5 Files
The HDF5.jl package allows you to work with HDF5 files, which are commonly used for storing large datasets in scientific computing.
To install the HDF5 package, use:
Pkg.add("HDF5")
Reading HDF5 Files:
using HDF5

h5_file = h5open("data.h5", "r")  # Open file in read-only mode
data = read(h5_file, "dataset_name")
println(data)
Writing HDF5 Files:
h5_file = h5open("output.h5", "w")  # Open file in write mode
write(h5_file, "new_dataset", data)

2. Working with CSV, JSON, HDF5, and Other Data Formats in Julia
Different file formats have their own strengths and are suitable for different types of data and applications. Let’s dive deeper into these formats and how to use them in Julia.
CSV: Ideal for tabular data (e.g., spreadsheets). CSV.jl is efficient and widely used in data science.
JSON: Great for storing hierarchical or nested data, commonly used in web APIs and configurations. JSON.jl makes it easy to parse and generate JSON data in Julia.
HDF5: Best for handling large scientific datasets with complex structures. HDF5.jl provides high-performance access to these files and is commonly used in scientific research and machine learning.
Excel: You can use the XLSX.jl package to read and write Excel files.
Parquet: A columnar storage format useful for analytics; you can use Parquet.jl to work with this format.
Pkg.add("XLSX")
using XLSX

# Read an Excel file
xlsx_data = XLSX.readxlsx("data.xlsx")

Data cleaning is a crucial step before performing analysis. In this section, we’ll focus on handling missing or malformed data using Julia’s built-in functions and packages.
Creating a Vector with Missing Values:
Replacing Missing Values:You can replace missing values with a default value using the coalesce() function:
cleaned_data = coalesce.(data, 0)  # Replace missing values with 0
Often, data contains duplicate rows or entries. Use the unique() function to remove duplicates from an array or DataFrame.
Removing Duplicates from an Array:
unique_data = unique([1, 2, 2, 3, 4, 4])
Removing Duplicates from a DataFrame:
df_cleaned = unique(df)

using CSV
using DataFrames

# Step 1: Read the CSV file
data = CSV.File("data/sample_data.csv") |> DataFrame

# Step 2: Clean data by removing missing values
clean_data = dropmissing(data)

# Step 3: Perform basic analysis
mean_value = mean(clean_data.ColumnName)
std_dev = std(clean_data.ColumnName)

println("Mean: ", mean_value)
println("Standard Deviation: ", std_dev)
Step 3: Run the ScriptSave the file and run it using Julia:
julia src/main.jl

For this challenge, you will create a function that takes a large CSV file and performs the following tasks:
using CSV
using DataFrames

function clean_data(file_path::String, output_path::String)
    # Step 1: Read the data
    data = CSV.File(file_path) |> DataFrame

    # Step 2: Remove duplicates
    data = unique(data)

    # Step 3: Handle missing values (replace with column mean)
    for col in names(data)
        if eltype(data[!, col]) == Missing
            mean_value = mean(skipmissing(data[!, col]))
        end
    end

    # Step 4: Write the cleaned data to a new CSV file
    CSV.write(output_path, data)
end

# Example usage
This function will scrub large CSV files, replacing missing values with column means and saving the cleaned data to a new file.

In this chapter, we covered how to efficiently read, write, and manipulate data from external files in Julia, using packages like CSV.jl, JSON.jl, and HDF5.jl. We explored best practices for cleaning and handling missing or malformed data, which is crucial for accurate analysis. The mini-project provided hands-on experience with these concepts, while the challenge allowed you to apply your knowledge to a more complex task involving data cleaning.
Data cleaning and manipulation are fundamental skills for any data-driven project. By mastering these techniques, you can ensure that your data is ready for analysis or modeling, leading to more accurate insights and better outcomes.
