Object-Oriented / Functional Patterns (Depending on the Language’s Style)
Julia is a multi-paradigm language, meaning that it supports both object-oriented programming (OOP) and functional programming (FP). Understanding how to effectively apply these two paradigms will help you write cleaner, more maintainable, and efficient code. This chapter will explore how to apply object-oriented principles in Julia using mutable and immutable structs, as well as how to implement functional programming techniques.
By the end of this chapter, you will:
Learn how to implement object-oriented principles using mutable and immutable structs in Julia.
1. Applying Object-Oriented Principles in Julia (using Mutable and Immutable Structs)
In Julia, the closest equivalent to classes in object-oriented programming is the struct. Structs are used to define new data types that can contain both data and functions. Julia supports mutable structs and immutable structs, which determine whether the data stored in the struct can be changed after the struct is created.
A mutable struct allows you to change the values of its fields after it is created. This is similar to classes with mutable state in OOP.
mutable struct Person
end

# Create an instance of the Person struct
# Modify the fields of the mutable struct
println(p)  # Output: Person("Alice", 31)
In this example, we create a mutable struct Person with two fields (name and age). After creating an instance of Person, we modify the age field. Mutable structs are useful when you want to allow changes to the object’s state.
An immutable struct is a type whose fields cannot be changed once the object is created. This is akin to immutable objects in other object-oriented languages like Python or Java.
immutable struct Point
end

# Create an instance of the Point struct
# Attempting to modify a field will throw an error
# p.x = 5.0  # Error: cannot assign a value to field x of const object
In this example, Point is an immutable struct. Once the object is created, the fields x and y cannot be modified.
Immutable structs are ideal when you want to ensure that the object’s state remains constant, which can lead to safer, more predictable code.

A pure function is a function that always produces the same output for the same input and has no side effects (i.e., it does not modify any external state).
function add(x, y)
end

println(add(3, 4))  # Output: 7
This add function is pure because it always returns the same result for the same inputs and does not change any external state.
A higher-order function is a function that either takes one or more functions as arguments, returns a function as a result, or both.
function apply_function(f, x, y)
end

println(result)  # Output: 7
In this example, apply_function is a higher-order function that takes a function f and applies it to the arguments x and y.
Immutability is a core principle of functional programming. In Julia, we encourage immutability by using immutable structs and avoiding side-effects in functions. This leads to predictable code and simplifies debugging.

3. Combining OOP and Functional Programming for Efficient, Maintainable Code
While Julia allows you to use both OOP and functional programming techniques, you can often achieve better results by combining them. For instance, you can use immutable structs for data representation and functional techniques for processing that data in a clean and reusable way.
Consider a scenario where we need to model a Circle with a radius and calculate its area. We can represent the circle with an immutable struct and define functional operations to interact with it.
immutable struct Circle
end
function area(circle::Circle)
end

function circumference(circle::Circle)
end
Here, the Circle struct is immutable, and the functions area and circumference are pure functions that operate on the Circle object.
println("Area: ", area(c))             # Output: Area: 78.5398
println("Circumference: ", circumference(c))  # Output: Circumference: 31.4159
In this mini-project, you will build a class-like structure using mutable structs and define methods that operate on the data encapsulated in these structures. Let’s create a BankAccount class that allows depositing, withdrawing, and checking the balance.
mutable struct BankAccount
end
Step 2: Define Methods for the BankAccount
function deposit(account::BankAccount, amount::Float64)
end

function withdraw(account::BankAccount, amount::Float64)
    if account.balance >= amount
    else
        println("Insufficient funds!")
    end
end

function check_balance(account::BankAccount)
end
println("Balance after deposit: ", check_balance(account))  # Output: 1200.0

println("Balance after withdrawal: ", check_balance(account))  # Output: 1050.0
In this mini-project, we modeled a BankAccount using a mutable struct and defined several methods to interact with the account’s state.

mutable struct Student
end

function increase_grade(student::Student)
end

println(s.grade)  # Output: 86
Use an immutable struct for Student.
immutable struct Student
end

function increase_grade(student::Student)
end

println(new_student.grade)  # Output: 86
In this chapter, we explored how to apply object-oriented programming (OOP) and functional programming (FP) techniques in Julia. We learned how to create mutable and immutable structs to model objects, and how to write pure functions for clean, reusable code. We also explored how to combine these paradigms to produce efficient, maintainable code that is easy to understand and extend.
Through the mini-project and challenge, we practiced implementing and refactoring code using both object-oriented and functional programming styles. By mastering these techniques, you can create robust and flexible Julia applications that can scale efficiently while maintaining readability and maintainability.
