As you progress from small scripts to more complex Julia projects, it’s essential to understand how to structure, organize, and manage your code effectively. In this chapter, we will dive into building a mid-sized project in Julia, such as a CLI tool, REST API, or simulation. These types of projects are commonly encountered in professional development and are excellent for honing your skills.
How to build a CLI tool or a REST API using the HTTP.jl library.
How to manage project dependencies, organize code, and write reusable modules.
By the end of this chapter, you'll be equipped to take on more complex Julia projects and structure your code for scalability, maintainability, and performance.

When working on mid-sized projects, organizing the project structure is key. This ensures that the codebase remains manageable as the project grows and that it is easy to extend and maintain.
Here is a recommended folder structure for a Julia project:
├── src/              # Source code files
│   ├── main.jl       # Entry point for the project
│   ├── module1.jl    # Module for a specific functionality
│   └── module2.jl    # Another module
├── data/             # Store data files (e.g., CSV, JSON, etc.)
├── test/             # Unit tests for the project
├── Project.toml      # Project dependencies
└── README.md         # Project documentation
src/: This is where the main code for the project resides. It includes a main.jl file that serves as the entry point for your project, as well as various modules to handle specific tasks.
Project.toml: Manages project dependencies and metadata.
README.md: A file for documenting the project, explaining its functionality, and providing instructions on installation and usage.
HTTP.jl is a Julia package that allows you to build HTTP servers for creating REST APIs. In this section, we will walk through building a basic REST API that supports CRUD (Create, Read, Update, Delete) operations.
Step 1: Install Dependencies
Start by installing HTTP.jl and JSON.jl for handling HTTP requests and JSON data.
using Pkg
Pkg.add("HTTP")
Pkg.add("JSON")
using HTTP
using JSON

# Data (in-memory for this example)
users = Dict(
    1 => Dict("name" => "Alice", "age" => 30),
    2 => Dict("name" => "Bob", "age" => 25)
# Handle GET requests
function handle_get(request)
    id = parse(Int, HTTP.URI(request).path[2])  # Extract ID from URL path
    user = get(users, id, nothing)
    if user == nothing
    else
        return HTTP.Response(200, JSON.json(user))
    end
end

# Handle POST requests
function handle_post(request)
    body = JSON.parse(String(request.body))
    id = length(users) + 1  # Generate a new ID
end

# Routes
function app(request::HTTP.Request)
    if request.method == HTTP.GET
        return handle_get(request)
    elseif request.method == HTTP.POST
    else
    end
end

# Start the server on port 8080
HTTP.serve(app, "0.0.0.0", 8080)
julia main.jl
The server will start on http://localhost:8080, and you can test the following routes:
Pkg.add("ArgParse")
using ArgParse

function factorial(n::Int)
end

function main()
    # Define command-line arguments
    # Calculate factorial
    println("Factorial of $(args["number"]) is: $result")
end

julia main.jl -n 5
3. Managing Project Dependencies, Organizing Code, and Writing Reusable Modules
3.1 Managing Project Dependencies
Julia uses the Pkg system to manage project dependencies. Each project should have a Project.toml file that lists its dependencies. To add a new dependency, use:
Pkg.add("DependencyName")
This ensures that your project will consistently use the required versions of dependencies.
A key part of organizing your project is creating reusable modules. Instead of writing all your code in the main.jl file, you can create separate files for different parts of your project.
module MathOperations

function add(a, b)
end

function subtract(a, b)
end

end  # module
include("math_operations.jl")
using .MathOperations

println(add(3, 5))
println(subtract(10, 4))
This modular approach helps you structure your code into logical components and makes it easier to maintain and extend.
Now, let’s apply what we’ve learned to build a small REST API using HTTP.jl and JSON.jl that performs basic CRUD operations. The API will manage user data, including creating, reading, updating, and deleting users.
Step 1: Set Up Dependencies
Pkg.add("HTTP")
Pkg.add("JSON")
using HTTP
using JSON

# In-memory storage for users
users = Dict()

# Define CRUD operations (Create, Read, Update, Delete)
function handle_post(request)
    user = JSON.parse(String(request.body))
end

function handle_get(request)
    user = get(users, id, nothing)
    if user == nothing
    else
        return HTTP.Response(200, JSON.json(user))
    end
end

function handle_put(request)
    user = JSON.parse(String(request.body))
    if haskey(users, id)
    else
    end
end

function handle_delete(request)
    if haskey(users, id)
    else
    end
end

# Routing function
function app(request::HTTP.Request)
    if request.method == HTTP.POST
    elseif request.method == HTTP.GET
        return handle_get(request)
    elseif request.method == HTTP.PUT
    elseif request.method == HTTP.DELETE
    else
    end
end

# Start server
HTTP.serve(app, "0.0.0.0", 8080)
5. Challenge: Implement User Authentication and Data Validation for a Basic Web Application
In this chapter, we explored how to structure and develop a mid-sized project in Julia. We learned how to build a CLI tool and a REST API using HTTP.jl, and how to manage project dependencies and organize code into reusable modules. The mini-project and challenge allowed you to put these concepts into practice by building a REST API with basic CRUD operations, user authentication, and data validation.
