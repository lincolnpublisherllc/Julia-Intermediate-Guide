Concurrency and Parallelism (Threads, Actors, Async Models)98
2. Using Threads for Multi-Threaded Execution100
3. Understanding the Actor Model for Concurrent Computation102
4. Using Async Programming for Handling I/O-bound Tasks104
