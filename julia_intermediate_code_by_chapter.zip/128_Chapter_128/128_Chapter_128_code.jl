3. Mini-Project: Simple Data Processing Script for File I/O and Basic Statistics33
