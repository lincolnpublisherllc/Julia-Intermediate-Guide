Concurrency and Parallelism (Threads, Actors, Async Models)
As computational problems grow in size and complexity, the need for more efficient computation becomes increasingly important. Concurrency and parallelism are essential techniques for handling performance bottlenecks in modern applications.
Concurrency refers to the ability of a system to handle multiple tasks at once, making progress on several tasks even if only one task is being executed at any given time.
Using Threads for multi-threaded execution.
Understanding the Actor model for concurrent computation.
Using asynchronous programming for I/O-bound tasks.
We’ll also walk through a mini-project to implement parallelized computations and a challenge to optimize a computationally expensive simulation using multi-threading.
By the end of this chapter, you will have a solid understanding of how to write concurrent and parallel code in Julia and how to scale your programs to take advantage of modern multi-core processors.

Julia provides multiple mechanisms for writing concurrent and parallel code, including the use of multi-threading, actor-based models, and asynchronous programming. Julia is well-suited for parallel computing due to its built-in support for multi-threading, distributed computing, and its JIT compiler that can optimize parallel workloads.
2. Using Threads for Multi-Threaded Execution
Julia has built-in support for multi-threading, which allows you to run multiple threads concurrently on multiple CPU cores. This can dramatically speed up computationally intensive tasks that can be split into independent subtasks.
export JULIA_NUM_THREADS=4  # Set to 4 threads
Using Threads for Parallel Execution
The Threads module in Julia provides easy access to multi-threading. You can use the @threads macro to parallelize a loop over multiple threads.
Example of a Parallelized for Loop:
using Base.Threads

function parallel_sum(data::Vector{Int})
    @threads for i in 1:length(data)
    end
end

data = 1:1000000  # A large vector of numbers
println(parallel_sum(data))
The @threads macro automatically distributes the loop iterations across available threads.
Best Practices for Multi-Threading in Julia
3. Understanding the Actor Model for Concurrent Computation
The Actor model is a mathematical model of computation that treats "actors" as the fundamental units of computation. In the Actor model, each actor is an independent entity that:
Sends messages to other actors.
The Actors.jl package in Julia provides a way to work with the Actor model. Each actor is isolated from others, which helps simplify concurrent computations by avoiding shared mutable state.
Using Actors in Julia
You can create actors in Julia by using ActorRef objects, which represent instances of actors.
using Actors

# Define a simple actor
function simple_actor(state, msg)
    if msg == "hello"
        println("Actor says hello!")
    else
        println("Actor received unknown message.")
    end
    return state  # Return the actor's state (unchanged in this case)
end

# Create the actor with an initial state
actor = spawn(simple_actor, "initial_state")

# Send messages to the actor
send!(actor, "hello")
send!(actor, "unknown")
The actor is created and listens for messages.
Event-driven systems: Where computations depend on events and need to react to messages.

4. Using Async Programming for Handling I/O-bound Tasks
Asynchronous programming allows you to run multiple tasks concurrently without blocking the main thread. This is especially useful for I/O-bound tasks, such as reading from files, making HTTP requests, or interacting with databases, where waiting for external operations can slow down your program.
Julia’s @async macro and @scheduled allow you to write asynchronous code that runs concurrently.
function download_file(url::String)
    println("Starting to download: $url")
    sleep(2)  # Simulate a delay for downloading
    println("Finished downloading: $url")
end

@async download_file("http://example.com/file1")
@async download_file("http://example.com/file2")
Best Practices for Async Programming
Use @async when tasks don’t depend on each other and can run concurrently.
Use @await when you need to wait for the completion of an asynchronous task before proceeding.

In this mini-project, you will implement a simple numerical simulation (e.g., Monte Carlo simulation) and parallelize it using Julia’s multi-threading capabilities.
Step 1: Simulate a Monte Carlo SimulationMonte Carlo simulations are used to model complex systems and estimate outcomes using random sampling. Let’s estimate the value of π using a Monte Carlo simulation.
function estimate_pi(n::Int)
    for _ in 1:n
        if x^2 + y^2 <= 1
        end
    end
end

# Estimate π with 1 million samples
println(estimate_pi(1_000_000))
Step 2: Parallelize the Simulation with @threadsWe’ll parallelize the Monte Carlo simulation to speed up the process by dividing the work across multiple threads.
using Base.Threads

function parallel_estimate_pi(n::Int)
    @threads for _ in 1:n
        if x^2 + y^2 <= 1
        end
    end
end

# Parallelized version of the Monte Carlo simulation
println(parallel_estimate_pi(1_000_000))

In this challenge, you will take a computationally expensive simulation (such as the fibonacci sequence calculation) and optimize it by parallelizing it using multi-threading.
function fibonacci(n::Int)
    if n <= 1
    else
    end
end

# Test with a large number
println(fibonacci(35))
Optimized Code (using threads):
using Base.Threads

function parallel_fibonacci(n::Int)
    if n <= 1
    else
        return @threads for i in 1:n
        end
    end
end

println(parallel_fibonacci(35))
In this chapter, we explored concurrency and parallelism in Julia, learning how to efficiently handle multiple tasks using Threads, the Actor model, and asynchronous programming. We practiced applying these concepts to parallelize computations, specifically using multi-threading to improve performance in a Monte Carlo simulation. Finally, the challenge helped you optimize a computationally expensive task, using the right concurrency tools.
