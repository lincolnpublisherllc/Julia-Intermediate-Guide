Data Structures in Depth (Sets, Maps, Trees, Tuples)62
4. Tuples in Julia68
6. Mini-Project: Implement a Basic Search Tree for Numeric Data70
